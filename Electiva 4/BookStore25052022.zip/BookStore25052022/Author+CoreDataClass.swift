//
//  Author+CoreDataClass.swift
//  BookStore29052022
//
//  Created by alexis on 29/5/22.
//  Copyright © 2022 alexis. All rights reserved.
//

import Foundation
import CoreData

@objc(Author)
public class Author: NSManagedObject {

}
