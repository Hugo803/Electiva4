//
//  Book+CoreDataClass.swift
//  BookStore25052022
//
//  Created by alexis on 25/5/22.
//  Copyright © 2022 alexis. All rights reserved.
//

import Foundation
import CoreData

@objc(Book)
public class Book: NSManagedObject {

}
