//: Playground - noun: a place where people can play
//Nombre:Amelia Violeta Hernandez Lopez
//Carnet: 25-1342-2017

import UIKit

// primera parte Elabore un programa que calcule la suma de nos numeros cualquiera, donde los valores deben ser de tipo float.
var nu1:Float = 3.369
var nu2:Float = 5.000
var resul:Float = 0.00
//operacion suma

resul=nu1 + nu2

print("La suma de \(nu1) mas \(nu2) es : \(resul)")


// Segunda parte Elabore un programa que calcule dos numero cualquiera, donde los valores sean float y el resultado sea int.
var v3:Float = 3.345
var v4:Float = 4.455
var r:Int = Int(v3*v4)
//operacion de multiplicacion

print("La mulplicacion de \(v3) por \(v4) es : \(r)")


//  parte 3

var A: Double = 0.0
var R: Double = 5.0
var pi = Double.pi
A = pi * (R*R)

print("El area es : \(A)")
