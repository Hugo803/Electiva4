// Gabriela Marisol Dominguez Hernandez
// 25-0925-2017

// ENUNCIADO:
// Elabore un programa que calcule la suma de nos numeros cualquiera, donde los valores deben ser de tipo float.

import Foundation

var num1:Float = 4.0
var num2:Float = 3.0
var suma:Float = 0.0

suma = num1 + num1

print(" El resultado de la suma de \(num1) + \(num2) = \(suma) \n\nRespuesta: \(suma)")