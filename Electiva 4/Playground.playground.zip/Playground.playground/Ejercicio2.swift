// Gabriela Marisol Dominguez Hernandez
// 25-0925-2017

// ENUNCIADO:
// Elabore un programa que multiplique dos numeros cualquiera, donde los valores sean float y el resultado sea int.

import Foundation

var num1:Float = 9.8
var num2:Float = 1.2
var resul:Int = Int(num1 * num2)

print("Resultado entero de la suma: \(resul)")